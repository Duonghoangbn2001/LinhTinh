Tất cả hình ảnh/video bạn tải từ wall của user/group/page sẽ được lưu tại đây
